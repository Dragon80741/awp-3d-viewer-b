<!-- README.md — @humkyung/viewer3d 소개·설치·사용·개발·배포 절차 -->
# @humkyung/viewer3d

nwx 타일 모델을 **보고 재는** React 3D 뷰어다. [MarkupFlow](https://github.com/humkyung/MarkupFlow) 에서 떼어 냈다.
설계는 MarkupFlow 의 [docs/viewer3d-package-plan.md](https://github.com/humkyung/MarkupFlow/blob/master/docs/viewer3d-package-plan.md) 에 있고,
진행은 [MarkupFlow#260](https://github.com/humkyung/MarkupFlow/issues/260) 에서 추적한다.

> 상태: **0.1.1** — 모델 트리·속성 패널(`ModelTreePanel`·`PropertyPane`)을 더했다. 0.1.0 은 MarkupFlow 안에서 앱과 떼어 낸 코어(P0)를 그대로 옮겨 온 것이다(P1).
> MarkupFlow 가 이 패키지로 바꿔 타는 것(P2)은 다음 단계다.

## 범위

- **넣는 것**
  - 카메라(궤도·줌·이동), nwx 타일 LOD 적재(예산·탈락 알림), 단일 GLB(DGN·SAT·작은 NWD)
  - 조명·AO·그림자
  - 측정(거리·각도)·배관 간격 치수 계산
  - 숨기기/격리, 단면(상자·임의 평면), 선택(선택 단위)·포커스·호버 강조
  - 뷰어 밖에 두는 **모델 트리**(`ModelTreePanel`)와 **속성 패널**(`PropertyPane`)
- **넣지 않는 것**: 툴바, 걷기/3인칭, 마크업, 협업, 저장 뷰포인트, Export.
  앱이 **자식 컴포넌트(확장)** 로 붙인다 — `useViewerRuntime()`·`useViewerFrame`·`useViewerPointer`·`useViewerClick`·`useViewerOverlay` 등.

## 설치

비공개 패키지라 **설치할 때도 토큰이 필요하다**(`read:packages`). 프로젝트의 `.npmrc` 는 이렇게 쓴다.

```
@humkyung:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NPM_TOKEN}
```

- 토큰 값을 `.npmrc` 에 직접 쓰지 않는다. `NPM_TOKEN` 환경변수로 넘긴다.
- Docker 빌드에서는 ARG 로 넘기지 말고 build secret 으로 넘긴다. ARG 로 넘기면 이미지 레이어에 토큰이 남는다.

```bash
npm install @humkyung/viewer3d three react react-dom
```

- `three`·`react`·`react-dom` 은 peer 의존이다. 앱이 가진 한 벌을 쓴다.
- glTF 파싱 worker 는 번들 안에 inline 으로 들어 있고 Blob URL 로 뜬다. CSP 를 쓰면 `worker-src blob:` 을 허용한다.

## 사용

```tsx
import { Viewer3D, createViewerStore, createHttpTileSource, useViewerState } from '@humkyung/viewer3d'
import '@humkyung/viewer3d/style.css'

const store = createViewerStore()   // 컨트롤러 — 버튼(명령)과 표시(읽기)가 모두 이것으로 뷰어를 부린다
const source = createHttpTileSource({ baseUrl: '/api/models/42/tiles', fetch: appFetch })

function App() {
  const measure = useViewerState(store, (s) => s.measureMode)
  return (
    <>
      <button onClick={() => store.getState().setMeasureMode(measure === 'dist' ? 'none' : 'dist')}>거리</button>
      <button onClick={() => store.getState().requestFitAll()}>맞춤</button>
      <Viewer3D documentId="42" source={source} store={store} onLog={(e) => showToast(e)} />
    </>
  )
}
```

- **`source`**: 타일을 어디서 받을지. 서버 배치면 `createHttpTileSource`, 다른 배치면 `TileSource` 를 직접 짠다(예제의 `folderTileSource.ts`).
  인증이 걸린 서버면 **앱의 fetch** 를 넘긴다 — 전역 fetch 는 401 자동 갱신을 타지 않아, 큰 모델을 받는 도중 토큰이 만료되면 나머지 타일이 전부 실패한다.
- **`onLog`**: 적재 실패·예산 탈락 같은 알림. 넘기지 않으면 콘솔로만 간다 — 사용자가 실패를 모르게 되니 넘긴다.
- **`translate`**: 문구. 없으면 기본 ko/en(브라우저 언어). 키 목록은 `ViewerMessageKey`.
- **`style.css`**: 빠뜨려도 캔버스·오버레이 자리는 어긋나지 않지만 패널 모양이 사라진다. 색은 CSS 변수(`--v3d-panel-bg` 등)로 덮어쓴다.
- **트리·속성 패널**: 뷰어와 **같은 스토어**를 넘긴다. 화면 어디에 둘지는 앱이 정하고(높이는 부모가 준다), 선택·숨김은 스토어로 서로 따라간다.
  ```tsx
  <ModelTreePanel store={store} />
  <PropertyPane store={store} fetch={source.fetch} />   // 원본 변환 기록을 받을 fetch — 인증 서버면 공급자의 것
  ```
  색은 `--v3d-side-*` 변수(`--v3d-side-bg`·`--v3d-side-text` 등)로 덮어쓴다. 아직 안 받은 구역의 줄은 흐리게 두고 까닭만 알린다 —
  그 자리로 **가는** 것은 부재 상자를 줄 서버가 있어야 해서 패키지 몫이 아니다.
- 그 밖의 prop(`partPick`·`insets`·`ao`·`shadow`·`fitSeq`·`initialFocusBox`·`globalKeys`·`triangleBudget`·`children`)은 `Viewer3DProps` 주석을 본다.

## 예제

[`examples/basic`](examples/basic) — nwx `--tiles` 폴더 URL 하나로 뷰어를 띄우고, 컨트롤러로 맞춤·거리·각도·단면 버튼과 오른쪽 트리·속성 패널을 붙인다. Tailwind 등 아무 CSS 도 없는 앱이다.

```bash
npm run build
cd examples/basic
npm install
npm run dev
```

브라우저에서 `http://localhost:9200/?tiles=<폴더 URL>` 을 연다. 폴더는 `nwx 원본.nwd --tiles <폴더>` 가 낸 것이고, 다른 출처에서 내준다면 CORS 를 허용해야 한다.

## 개발

```bash
npm install
npm run typecheck
npm run build
```

MarkupFlow 에서 바로 확인하려면 `npm link` 를 쓴다.
- `package.json` 은 배포 버전을 그대로 둔다.
- 앱의 `vite.config` 에 `resolve.dedupe: ['three', 'react', 'react-dom', 'zustand']` 를 둔다. 그래야 three 가 두 벌 잡히지 않는다(예제도 그렇게 한다).

## 배포

1. `package.json` 의 `version` 을 올린다.
2. 같은 이름의 태그(`v0.1.1`)를 push 한다.
3. `.github/workflows/publish.yml` 이 태그와 버전이 일치하는지 확인하고 GitHub Packages 에 올린다.
4. CI 가 못 돌면(계정 Actions 결제 문제 — 0.1.0 이 그랬다) 로컬에서 `npm publish` 한다. 토큰은 **classic PAT**(`write:packages` + `repo`)를
   `NPM_TOKEN` 에 넣는다 — fine-grained 토큰이나 `repo` 없는 토큰은 `E403 … does not match expected scopes` 로 거절된다.

워커 소스맵(`dist/assets/*.map`, 3 MB)은 `files` 에서 뺀다(0.1.1). 본체 소스맵(`index.js.map`)은 남긴다.
`npm run build` 는 맨 앞에서 `dist` 를 비운다(`clean`) — 비우지 않으면 지우거나 이름을 바꾼 파일의 옛 선언이 함께 배포된다.
